﻿using System.Collections.Generic;

namespace RestSharp.Tests.SampleClasses
{
    public class JsonLists
    {
        public List<string> Names { get; set; }

        public List<int> Numbers { get; set; }
    }
}
